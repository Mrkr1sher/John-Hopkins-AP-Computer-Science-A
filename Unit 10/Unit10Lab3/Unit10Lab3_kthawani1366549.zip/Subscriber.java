public class Subscriber {
    public void update() {
    }
}